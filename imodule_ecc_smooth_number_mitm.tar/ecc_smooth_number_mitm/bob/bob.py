import socket
import json
from ecc import ECC

MITM_IP = '172.25.0.3'
MITM_PORT = 5001

ecc = ECC()
priv, pub = ecc.generate_keypair()
print("[Bob] Khóa công khai:", pub)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((MITM_IP, MITM_PORT))

try:
    # Gửi khóa công khai lần đầu
    pub_data = json.dumps({"Qx": pub[0], "Qy": pub[1]})
    s.send(pub_data.encode('utf-8'))
    print("[Bob] Đã gửi khóa công khai đến Alice")

    # Nhận khóa công khai của Alice
    data = s.recv(4096).decode('utf-8')
    if not data:
        raise ConnectionError("Không nhận được khóa công khai của Alice")
    alice_val = json.loads(data)
    alice_pub = (alice_val["Qx"], alice_val["Qy"])
    print("[Bob] Nhận khóa công khai của Alice:", alice_pub)

    while True:
        # Nhận ciphertext từ Alice
        data = s.recv(4096).decode('utf-8')
        if not data:
            print("[Bob] Không nhận được dữ liệu từ Alice")
            break

        response = json.loads(data)
        if "ciphertexts" in response:
            blocks = response["ciphertexts"]
            # Giải mã: Alice encrypt dùng bob_pub, nên Bob decrypt trừ bob_pub_x
            plain = ecc.decrypt(blocks, priv, sender_pub=pub)
            print(f"[Bob] Nhận từ Alice ({len(blocks)} blocks):", plain)

            # Nhập phản hồi
            msg = input("[Bob] Nhập thông điệp phản hồi (hoặc 'exit' để thoát): ").strip()
            if not msg:
                continue
            if msg.lower() == "exit":
                print("[Bob] Thoát mà không gửi thông điệp tới Alice")
                break

            # Mã hóa và gửi
            new_blocks = ecc.encrypt(msg, alice_pub)
            msg_data = json.dumps({"ciphertexts": new_blocks})
            s.send(msg_data.encode('utf-8'))
            print(f"[Bob] Đã gửi {len(new_blocks)} block ciphertext:", new_blocks)
        else:
            print("[Bob] Dữ liệu không đúng định dạng")

finally:
    print("[Bob] Đóng kết nối")
    s.close()

