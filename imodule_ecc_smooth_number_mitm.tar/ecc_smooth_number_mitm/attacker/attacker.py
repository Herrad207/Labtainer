import socket
import threading
import json
import subprocess
from Crypto.Util.number import long_to_bytes
from ecc import ECC
import sys

LISTEN_IP = '0.0.0.0'
ALICE_PORT = 5000
BOB_PORT = 5001
BUFFER_SIZE = 4096

ecc = ECC()

def mitm_decrypt(ciphertexts, peer_pub_x, p):
    """
    Nhận ciphertexts là int hoặc list[int], giải từng block, 
    nối lại thành chuỗi UTF-8.
    Trả về (plain_str, err_msg).
    """
    # chuẩn hóa thành list
    if isinstance(ciphertexts, int):
        blocks = [ciphertexts]
    else:
        blocks = ciphertexts

    full_bytes = bytearray()
    for c in blocks:
        m = (c - peer_pub_x) % p
        if m == 0:
            return None, "<DECODE ERROR: m = 0 sau giải mã>"
        data = long_to_bytes(m)
        if not data:
            return None, "<DECODE ERROR: Empty data>"
        length = data[0]
        if length > len(data) - 1:
            print(f"[MITM] Cảnh báo: Length byte vượt quá ({length} > {len(data)-1}), điều chỉnh length")
            length = len(data) - 1
        if length == 0:
            return None, "<DECODE ERROR: Length = 0>"
        full_bytes.extend(data[1:1+length])

    try:
        return full_bytes.decode('utf-8'), None
    except UnicodeDecodeError:
        return None, f"<DECODE ERROR: Invalid UTF-8 encoding, data={full_bytes.hex()}>"

def call_extract_privkey(Qx, Qy):
    # giữ nguyên
    ...

def intercept(src, dst, direction, pub_keys):
    try:
        while True:
            data = src.recv(BUFFER_SIZE).decode('utf-8')
            if not data:
                break

            print(f"[{direction}] Raw: {data}")
            try:
                val = json.loads(data)

                # Khóa công khai
                if "Qx" in val and "Qy" in val:
                    pub = (val["Qx"], val["Qy"])
                    print(f"[{direction}] Nhận khóa công khai: {pub}")
                    pub_keys[direction] = pub
                    dst.sendall(data.encode('utf-8'))
                    continue

                # Ciphertexts (danh sách)
                if "ciphertexts" in val:
                    blocks = val["ciphertexts"]

                    # Xác định khóa công khai của người nhận
                    receiver_key = "Bob -> Alice" if direction == "Alice -> Bob" else "Alice -> Bob"
                    receiver_pub = pub_keys.get(receiver_key)
                    if not receiver_pub:
                        print(f"[{direction}] Thiếu khóa công khai của người nhận")
                        dst.sendall(data.encode('utf-8'))
                        continue

                    # MITM giải mã và in
                    plain, err = mitm_decrypt(blocks, receiver_pub[0], ecc.p)
                    if err:
                        print(f"[{direction}] Giải mã thất bại: {err}")
                    else:
                        print(f"[{direction}] Đã giải mã: {plain}")

                    # Cho phép MITM giả mạo
                    inject = input(f"[{direction}] Nhập thông điệp giả mạo (enter để giữ nguyên): ").strip()
                    if inject:
                        print("[FAKE MESSAGE] " + inject)
                        sys.stdout.flush()
                        try:
                            new_blocks = ecc.encrypt(inject, receiver_pub)
                            data = json.dumps({"ciphertexts": new_blocks})
                        except Exception as e:
                            print(f"[{direction}] Lỗi mã hóa giả mạo: {e}")
                            # giữ nguyên data cũ

            except json.JSONDecodeError as e:
                print(f"[{direction}] JSON lỗi: {e}")
            except Exception as e:
                print(f"[{direction}] Lỗi xử lý: {e}")

            # Gửi tiếp (dù đã thay data hay không)
            dst.sendall(data.encode('utf-8'))

    except Exception as e:
        print(f"[{direction}] Lỗi kết nối: {e}")
    finally:
        src.close()
        dst.close()

def mitm():
    pub_keys = {"Alice -> Bob": None, "Bob -> Alice": None}

    # Lắng nghe Alice
    alice_listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    alice_listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    alice_listener.bind((LISTEN_IP, ALICE_PORT))
    alice_listener.listen(1)
    print("[MITM] Đang chờ Alice kết nối...")
    alice_conn, _ = alice_listener.accept()
    print("[MITM] Alice đã kết nối")

    # Lắng nghe Bob
    bob_listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    bob_listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    bob_listener.bind((LISTEN_IP, BOB_PORT))
    bob_listener.listen(1)
    print("[MITM] Đang chờ Bob kết nối...")
    bob_conn, _ = bob_listener.accept()
    print("[MITM] Bob đã kết nối")

    threading.Thread(target=intercept, args=(alice_conn, bob_conn, "Alice -> Bob", pub_keys), daemon=True).start()
    threading.Thread(target=intercept, args=(bob_conn, alice_conn, "Bob -> Alice", pub_keys), daemon=True).start()

    # Giữ thread chính không kết thúc
    try:
        print("[+] MITM is running... Press Ctrl+C to stop.", flush=True)
        threading.Event().wait()
    except KeyboardInterrupt:
        print("\n[+] MITM stopped gracefully.")

if __name__ == "__main__":
    mitm()

