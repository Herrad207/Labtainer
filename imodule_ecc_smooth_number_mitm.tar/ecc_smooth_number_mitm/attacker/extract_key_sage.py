from sage.all import GF, EllipticCurve
import sys
import json

def extract_privkey(Qx, Qy):
    p = 183740305291166889900894879302858411333
    a = 13
    b = 37
    Gx = 123764810000715262449972298016641419881
    Gy = 144640915410606177233842123838934486566

    # Kiểm tra đầu vào
    if not (0 <= Qx < p and 0 <= Qy < p):
        print(f"[!] Đầu vào Qx, Qy không hợp lệ: Qx={Qx}, Qy={Qy}")
        return None

    F = GF(p)
    E = EllipticCurve(F, [a, b])
    try:
        Q = E(Qx, Qy)
        G = E(Gx, Gy)
    except Exception as e:
        print(f"[!] (Qx, Qy) = ({Qx}, {Qy}) không nằm trên đường cong: {e}")
        return None

    n = G.order()
    print(f"[+] Bậc của G: {n}, factors: {n.factor()}")

    try:
        print("[+] Bắt đầu discrete_log...")
        priv_key = G.discrete_log(Q)
        if priv_key < 1 or priv_key >= n:
            print(f"[!] Khóa riêng không hợp lệ: {priv_key}")
            return None
        print(f"[+] Tính thành công khóa riêng: {priv_key}")
        return int(priv_key)
    except Exception as e:
        print(f"[!] Không thể tính discrete log: {e}")
        return None

if __name__ == "__main__":
    try:
        inp = sys.stdin.read()
        data = json.loads(inp)
        Qx = int(data["Qx"])
        Qy = int(data["Qy"])
    except json.JSONDecodeError as e:
        print(f"[!] Đọc đầu vào JSON lỗi: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"[!] Đọc đầu vào lỗi: {e}")
        sys.exit(1)

    priv = extract_privkey(Qx, Qy)
    if priv is not None:
        print(priv)
    else:
        print("None")
