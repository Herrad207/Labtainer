from sage.all import GF, EllipticCurve

def main():
    p = 183740305291166889900894879302858411333
    a = 13
    b = 37
    Gx = 123764810000715262449972298016641419881
    Gy = 144640915410606177233842123838934486566

    F = GF(p)
    E = EllipticCurve(F, [a, b])
    G = E(Gx, Gy)

    priv = int(input("Enter your private key (integer): ").strip())
    A = priv * G
    Qx, Qy = int(A[0]), int(A[1])
    print(f"Your public key is:\n  Qx = {Qx}\n  Qy = {Qy}")

if __name__ == "__main__":
    main()

