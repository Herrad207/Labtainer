import socket
import json
from ecc import ECC

MITM_IP = '172.25.0.3'
MITM_PORT = 5000

ecc = ECC()
priv, pub = ecc.generate_keypair()
print("[Alice] Khóa công khai:", pub)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((MITM_IP, MITM_PORT))

try:
    # Gửi khóa công khai lần đầu
    pub_data = json.dumps({"Qx": pub[0], "Qy": pub[1]})
    s.send(pub_data.encode('utf-8'))
    print("[Alice] Đã gửi khóa công khai đến Bob")

    # Nhận khóa công khai của Bob
    data = s.recv(4096).decode('utf-8')
    if not data:
        raise ConnectionError("Không nhận được khóa công khai của Bob")
    bob_val = json.loads(data)
    bob_pub = (bob_val["Qx"], bob_val["Qy"])
    print("[Alice] Nhận khóa công khai của Bob:", bob_pub)

    while True:
        # Nhập thông điệp
        msg = input("[Alice] Nhập thông điệp gửi Bob (hoặc 'exit' để thoát): ").strip()
        if not msg:
            continue
        if msg.lower() == "exit":
            print("[Alice] Thoát mà không gửi thông điệp tới Bob")
            break

        # Mã hóa (trả về list các block) và gửi
        ciphertexts = ecc.encrypt(msg, bob_pub)
        msg_data = json.dumps({"ciphertexts": ciphertexts})
        s.send(msg_data.encode('utf-8'))
        print(f"[Alice] Đã gửi {len(ciphertexts)} block ciphertext:", ciphertexts)

        # Nhận phản hồi
        data = s.recv(4096).decode('utf-8')
        if not data:
            print("[Alice] Không nhận được dữ liệu từ Bob")
            break

        response = json.loads(data)
        if "ciphertexts" in response:
            blocks = response["ciphertexts"]
            # Giải mã phản hồi: Bob encrypt dùng alice_pub, nên Alice decrypt trừ alice_pub_x
            plain = ecc.decrypt(blocks, priv, sender_pub=pub)
            print("[Alice] Nhận từ Bob:", plain)
        else:
            print("[Alice] Dữ liệu không đúng định dạng")

finally:
    print("[Alice] Đóng kết nối")
    s.close()

