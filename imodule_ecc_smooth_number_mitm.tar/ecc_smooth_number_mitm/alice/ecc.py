from Crypto.Util.number import long_to_bytes, bytes_to_long, getRandomRange
from sage.all import GF, EllipticCurve
from math import floor

class ECC:
    def __init__(self):
        self.p = 183740305291166889900894879302858411333
        self.a = 13
        self.b = 37
        self.G = (
            123764810000715262449972298016641419881,
            144640915410606177233842123838934486566
        )
        self.F = GF(self.p)
        try:
            self.E = EllipticCurve(self.F, [self.a, self.b])
            self.G_point = self.E(self.G[0], self.G[1])
            self.n = int(self.G_point.order())
        except Exception as e:
            raise ValueError(f"Lỗi khởi tạo đường cong: {e}")

        # tính kích thước block tối đa: mỗi block gồm 1 byte độ dài + dữ liệu
        # đảm bảo (1 + max_block_size) bytes ít hơn p
        self.max_block_size = floor((self.p.bit_length() - 1) / 8) - 1

    def generate_keypair(self):
        if not hasattr(self, 'n') or self.n <= 1:
            raise ValueError("Bậc của G không hợp lệ")
        priv = getRandomRange(1, self.n)
        pub_point = priv * self.G_point
        pub = (int(pub_point[0]), int(pub_point[1]))
        return priv, pub

    def encrypt(self, msg: str, peer_pub: tuple):
        """
        Trả về danh sách ciphertext ints, mỗi phần tương ứng một block.
        """
        try:
            msg_bytes = msg.encode('utf-8')
            blocks = []
            # chia nhỏ theo max_block_size
            for i in range(0, len(msg_bytes), self.max_block_size):
                chunk = msg_bytes[i:i + self.max_block_size]
                length = len(chunk)
                # ghi độ dài rồi nối chunk
                data = bytes([length]) + chunk
                m = bytes_to_long(data)
                # đảm bảo m < p
                assert m < self.p, "Thuật toán chia block sai kích thước"
                # tính c = (m + x_peer) mod p
                c = (m + peer_pub[0]) % self.p
                # nếu kết quả là 0 thì gán về p
                if c == 0:
                    c = self.p
                blocks.append(c)
            return blocks
        except Exception as e:
            raise ValueError(f"Lỗi mã hóa: {e}")

    def decrypt(self, ciphertexts: list, privkey: int, sender_pub: tuple):
        """
        Nhận danh sách ciphertexts, giải từng block rồi ghép lại thành chuỗi UTF-8.
        """
        if not (0 < privkey < self.n):
            return f"<DECODE ERROR: Khóa riêng không hợp lệ ({privkey})>"
        if sender_pub is None:
            return "<DECODE ERROR: Thiếu khóa công khai của người gửi>"

        full_bytes = bytearray()
        for c in ciphertexts:
            if not (0 <= c <= self.p):
                return f"<DECODE ERROR: Ciphertext không hợp lệ ({c})>"
            # khôi phục m
            m = (c - sender_pub[0]) % self.p
            if m == 0:
                return "<DECODE ERROR: m = 0 sau giải mã>"
            data = long_to_bytes(m)
            if len(data) < 1:
                return "<DECODE ERROR: No length byte>"
            length = data[0]
            if length > len(data) - 1:
                return f"<DECODE ERROR: Invalid length ({length} > {len(data)-1}), data={data.hex()}>"
            chunk = data[1 : 1 + length]
            full_bytes.extend(chunk)

        # cố gắng decode toàn bộ
        try:
            return full_bytes.decode('utf-8')
        except UnicodeDecodeError:
            return f"<DECODE ERROR: Invalid UTF-8 encoding, data={full_bytes.hex()}>"

