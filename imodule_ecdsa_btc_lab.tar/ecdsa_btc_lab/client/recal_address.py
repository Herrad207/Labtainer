import hashlib, base58
pubkey = bytes.fromhex(open("public_key.hex").read().strip())
pkh = hashlib.new('ripemd160', hashlib.sha256(pubkey).digest()).digest()
pref = b'\x00' + pkh
chk = hashlib.sha256(hashlib.sha256(pref).digest()).digest()[:4]
addr = base58.b58encode(pref + chk).decode()
server_addr = open("address.txt").read().strip()
print("Computed address:", addr)
print("Server’s address :", server_addr)
if addr == server_addr:
    print("Result: Addresses match.")
else:
    print("Result: Addresses do NOT match.")
