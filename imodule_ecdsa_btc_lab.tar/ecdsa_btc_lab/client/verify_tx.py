from ecdsa import VerifyingKey, SECP256k1, BadSignatureError
import hashlib

tx = open("sample_tx.json").read()
sig = bytes.fromhex(open("tx.sig").read().strip())
vk = VerifyingKey.from_string(bytes.fromhex(open("public_key.hex").read().strip()),
                              curve=SECP256k1)
h = hashlib.sha256(tx.encode()).digest()

try:
    vk.verify(sig, h)
    print("Signature is valid. Transaction approved.")
except BadSignatureError:
    print("Signature is invalid!")
