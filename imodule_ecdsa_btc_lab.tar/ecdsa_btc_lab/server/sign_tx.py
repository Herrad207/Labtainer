from ecdsa import SigningKey, SECP256k1
import json
import hashlib

# Load transaction
with open("sample_tx.json") as f:
    tx = f.read()
msg_bytes = tx.encode()

# Load private key
with open("private_key.pem") as f:
    sk = SigningKey.from_pem(f.read())

signature = sk.sign(msg_bytes).hex()  # ← lỗi nằm ở đây

with open("tx.sig", "w") as f:
    f.write(signature)

print(f"Transaction has been signed. Signature saved to tx.sig")

