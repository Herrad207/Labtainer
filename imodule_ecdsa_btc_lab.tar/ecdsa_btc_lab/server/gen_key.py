from ecdsa import SigningKey, SECP256k1
import binascii

sk = SigningKey.generate(curve=SECP256k1)
vk = sk.verifying_key

with open("private_key.pem", "wb") as f:
    f.write(sk.to_pem())

with open("public_key.hex", "w") as f:
    f.write(vk.to_string().hex())

print("ECC key pair generated:")
print("- Private key saved to private_key.pem")
print("- Public key (hex) saved to public_key.hex")

