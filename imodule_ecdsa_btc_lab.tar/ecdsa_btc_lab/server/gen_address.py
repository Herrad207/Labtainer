import hashlib, base58

# Đọc public key hex
with open("public_key.hex") as f:
    pubkey_bytes = bytes.fromhex(f.read().strip())

# SHA-256 → RIPEMD-160 → prefix mainnet (0x00)
pk_hash = hashlib.new('ripemd160', hashlib.sha256(pubkey_bytes).digest()).digest()
prefix = b'\x00' + pk_hash
checksum = hashlib.sha256(hashlib.sha256(prefix).digest()).digest()[:4]

# Địa chỉ ví Bitcoin
address = base58.b58encode(prefix + checksum).decode()
with open("address.txt", "w") as f:
    f.write(address)

print("Generated Bitcoin address:", address)

